﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.Q))
        {
            transform.localEulerAngles = new Vector3(transform.localEulerAngles.x, transform.localEulerAngles.y - 100, 0);
        }
        if (Input.GetKey(KeyCode.E))
        {
            transform.localEulerAngles = new Vector3(transform.localEulerAngles.x, transform.localEulerAngles.y + 100, 0);
        }
        if (Input.GetKey(KeyCode.W))
        {
            Vector3 forwardMovement = new Vector3(transform.forward.x, 0, transform.forward.z);
            GetComponent<Rigidbody>().AddForce(forwardMovement*0.1f, ForceMode.Impulse);
        }
        if (Input.GetKey(KeyCode.S))
        {
            Vector3 forwardMovement = new Vector3(transform.forward.x, 0, transform.forward.z);
            GetComponent<Rigidbody>().AddForce(-forwardMovement * 0.1f, ForceMode.Impulse);
        }
        if(Input.GetKeyDown(KeyCode.Q))
        {
            //Switch Mechanic
            int switchIndex = 0;
            GameObject[] cannonArray = GameObject.FindGameObjectsWithTag("Cannon");
            for(int i = 0; i < cannonArray.Length; i++)
            {
                if(gameObject == cannonArray[i])
                {
                    if(i == cannonArray.Length-1)
                    {
                        switchIndex = 0;
                    }
                    else
                    {
                        switchIndex = i + 1;
                    }
                }
            }
            //Switch next object on
            cannonArray[switchIndex].transform.FindChild("Main Camera").gameObject.SetActive(true);
            cannonArray[switchIndex].GetComponent<MouseLook>().enabled = true;
            cannonArray[switchIndex].GetComponent<Shoot>().enabled = true;
            cannonArray[switchIndex].GetComponent<PlayerMovement>().enabled = true;
            //Switch current object off
            transform.FindChild("Main Camera").gameObject.SetActive(false);
            GetComponent<Rigidbody>().freezeRotation = true;
            GetComponent<MouseLook>().enabled = false;
            GetComponent<Shoot>().enabled = false;
            this.enabled = false;
        }
    }
}
